module.exports.TypingNotifyDelay = 2000;
